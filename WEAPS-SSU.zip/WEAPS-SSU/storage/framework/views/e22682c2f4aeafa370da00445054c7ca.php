<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\kenne\Desktop\em-res\WEAPS-SSU\resources\views/vendor/filament/components/dropdown/list/index.blade.php ENDPATH**/ ?>