<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link href="<?php echo e(asset('src/outStyle.css')); ?>" rel="stylesheet">

    <style>
        .star-rating {
            display: flex;
            font-size: 1.75rem;
            cursor: pointer;
            gap: 0.25rem;
            align-items: center;
        }

        .star {
            transition: all 0.2s ease;
            color: #d1d5db;
            font-size: 1.75rem;
        }

        .star:hover {
            color: #fbbf24;
            transform: scale(1.1);
        }

        .star.active {
            color: #fbbf24;
        }

        .star-rating-container {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .rating-display {
            display: flex;
            font-size: 1.25rem;
            gap: 0.125rem;
        }

        .rating-display .star {
            color: #fbbf24;
            font-size: 1rem;
            margin-right: 0.125rem;
        }
    </style>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('src/outScript.js')); ?>"></script>

    <div id="company-page-root">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('company.profile');

$__html = app('livewire')->mount($__name, $__params, 'lw-455853668-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kenne\Desktop\em-res\WEAPS-SSU\resources\views/vendor/filament/filament/employeer/pages/company-page.blade.php ENDPATH**/ ?>