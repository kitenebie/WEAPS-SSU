<div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('career-list');

$__html = app('livewire')->mount($__name, $__params, 'lw-853957920-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</div><?php /**PATH C:\Users\kenne\Desktop\em-res\WEAPS-SSU\resources\views/filament/employeer/pages/careers.blade.php ENDPATH**/ ?>