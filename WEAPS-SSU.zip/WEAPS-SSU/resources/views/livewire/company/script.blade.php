<div>
    @script
        <!-- Scripts -->
        <script>
        </script>
    @endscript
</div>
