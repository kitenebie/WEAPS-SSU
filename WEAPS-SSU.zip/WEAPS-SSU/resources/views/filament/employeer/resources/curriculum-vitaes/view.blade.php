<x-filament-panels::page>
    @include('partials.cv-content', ['cv' => $record])
</x-filament-panels::page>