<div>
    @livewireStyles()
    @livewire('career-list')
    @livewireScripts()
</div>