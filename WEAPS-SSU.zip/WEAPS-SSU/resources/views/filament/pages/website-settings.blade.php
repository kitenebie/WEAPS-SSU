<x-filament-panels::page>
    {{ $this->content }}
</x-filament-panels::page>