<?php

namespace App\Livewire;

use Livewire\Component;

class ApplicantProfile extends Component
{
    public function render()
    {
        return view('livewire.applicant-profile');
    }
}
