<?php

namespace App\Filament\Resources\CurriculumVitaes\Pages;

use App\Filament\Resources\CurriculumVitaes\CurriculumVitaeResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCurriculumVitae extends CreateRecord
{
    protected static string $resource = CurriculumVitaeResource::class;
}
