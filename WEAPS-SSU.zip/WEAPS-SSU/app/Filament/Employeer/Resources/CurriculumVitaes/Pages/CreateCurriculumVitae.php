<?php

namespace App\Filament\Employeer\Resources\CurriculumVitaes\Pages;

use App\Filament\Employeer\Resources\CurriculumVitaes\CurriculumVitaeResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCurriculumVitae extends CreateRecord
{
    protected static string $resource = CurriculumVitaeResource::class;
}
